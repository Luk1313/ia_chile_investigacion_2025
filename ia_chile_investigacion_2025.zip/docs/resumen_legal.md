# 🧾 Resumen Legal - IA en Chile

## Principales avances

- **2021**: Se publica la Política Nacional de IA
- **2025**: Se actualiza con el Decreto Nº12
- **2024–2025**: Proyecto de Ley 16821-19 se tramita en el Congreso
- Clasificación de sistemas por riesgo: prohibido, alto, limitado, sin riesgo
- Notificación obligatoria de incidentes en 72h
- Consejo Asesor Técnico y espacio de pruebas (“sandbox”)

## Organismos relacionados

- Ministerio de Ciencia
- Agencia de Protección de Datos Personales
- Congreso Nacional
