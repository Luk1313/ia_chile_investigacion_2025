"""
Script para resumir textos usando OpenAI GPT.
"""

import openai

openai.api_key = "TU_API_KEY"

def resumir_texto(texto):
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": f"Resume: {texto}"}]
    )
    return response['choices'][0]['message']['content']

# Ejemplo de uso
if __name__ == "__main__":
    texto_original = "La IA en Chile ha sido regulada por..."
    print(resumir_texto(texto_original))
