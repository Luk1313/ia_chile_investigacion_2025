# 🛠 Taller: Conexión a ChatGPT desde Python

## Objetivo
- Conectar con la API de OpenAI
- Generar respuestas desde script local
- Automatizar tareas como resúmenes y respuestas rápidas

## Código base

```python
import openai

openai.api_key = "TU_API_KEY"

response = openai.ChatCompletion.create(
  model="gpt-4",
  messages=[{"role": "user", "content": "Resume este texto..."}]
)

print(response['choices'][0]['message']['content'])
```
