# 🇨🇱 IA en Chile - Investigación 2025

**Repositorio sobre regulación legal y guía práctica de Inteligencia Artificial en Chile.**

## Objetivo

- Explicar el marco legal chileno sobre IA (2021–2025)
- Proveer recursos para aprender IA desde cero
- Compartir ejemplos prácticos para analistas

## Contenido

- `/docs`: Decretos, leyes, políticas nacionales
- `/notebooks`: Cuadernos Colab de aprendizaje
- `/talleres`: Actividades paso a paso
- `/automatizaciones`: Scripts útiles (resumen de texto, conexión con APIs, etc.)

## Fuentes oficiales

- [Política Nacional de IA – MinCiencia](https://minciencia.gob.cl/areas/inteligencia-artificial/)
- [Proyecto de Ley 16821-19](https://www.bcn.cl/leychile/navegar?idNorma=1225782)
- [Latam-GPT – El País](https://elpais.com/chile/2025-06-04/latam-gpt-el-modelo...)

👤 Desarrollado por [@Luk1313](https://github.com/Luk1313)
